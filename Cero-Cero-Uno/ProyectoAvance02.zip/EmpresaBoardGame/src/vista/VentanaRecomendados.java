package vista;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VentanaRecomendados extends JFrame{
	
	CardLayout cardLayout;
	public JPanel panel;
	JPanel panelCentro;
	
	public VentanaRecomendados() {
		setSize(800, 650);// Ancho y largo, tamaño de la ventana
		setDefaultCloseOperation(EXIT_ON_CLOSE);// Cerrar
		setTitle("Recomendados");
		setLocationRelativeTo(null);// Establecemos la ventana en el centro
		setResizable(true);// La ventana es redimensionable
		this.setLayout(new BorderLayout(0, 10)); // espacio entre regiones

		iniciar();
	}

	private void iniciar() {
		
		panels();
		otro();
	}

	private void panels() {
		// labels utilizado para el titulo
		JLabel labelTitulo = new JLabel();

		labelTitulo.setText("Recomendados");
		labelTitulo.setForeground(Color.white);// color de la letra

		JPanel panelNorte = new JPanel();// norte,titulo
		JPanel panelSur = new JPanel();// sur
		panelCentro = new JPanel();// centro1
		// colores de los paneles
		

		panelNorte.setBackground(new Color(0, 68, 69));// Color CadetBlue

		panelSur.setBackground(new Color(111, 185, 143));// Panel sur, Color Greenery
		panelCentro.setBackground(new Color( 161,214,226));// centro1 color lagoon

		// el layout del panel uno esta null para poder mover los componentes
		// manualmente
		panelNorte.setLayout(new BorderLayout());// panelNorte es el norte-titulo

//dimensiones de los paneles		
		panelNorte.setPreferredSize(new Dimension(100, 80));

		panelSur.setPreferredSize(new Dimension(100, 80));
		panelCentro.setPreferredSize(new Dimension(100, 100));


//agregar paneles a sus respectivas posiciones

		this.add(panelNorte, BorderLayout.NORTH);
		this.add(panelSur, BorderLayout.SOUTH);
		this.add(panelCentro, BorderLayout.CENTER);
		// panel norte-titulo agregar label y botones
		panelNorte.add(labelTitulo, BorderLayout.WEST);
	}
	private void otro(){
	

				

	}
}
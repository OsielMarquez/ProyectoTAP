package vista;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class Ventana extends JFrame {

	CardLayout cardLayout;
	public JPanel panel;
	JPanel panelCentro;
	
	public Ventana() {
		setSize(800, 650);// Ancho y largo, tamaño de la ventana
		setDefaultCloseOperation(EXIT_ON_CLOSE);// Cerrar
		setTitle("Inventario");
		setLocationRelativeTo(null);// Establecemos la ventana en el centro
		setResizable(true);// La ventana es redimensionable
		this.setLayout(new BorderLayout(0, 10)); // espacio entre regiones

		iniciar();
	}

	private void iniciar() {
		
		panels();
		otro();
	}

	private void panels() {
		// labels utilizado para el titulo
		JLabel labelTitulo = new JLabel();

		labelTitulo.setText("Inventario");
		labelTitulo.setForeground(Color.white);// color de la letra

		JPanel panelNorte = new JPanel();// norte,titulo
		JPanel panelSur = new JPanel();// sur
		panelCentro = new JPanel();// centro1
		// colores de los paneles
		

		panelNorte.setBackground(new Color(0, 68, 69));// Color CadetBlue

		panelSur.setBackground(new Color(111, 185, 143));// Panel sur, Color Greenery
		panelCentro.setBackground(new Color(134,172,65));// centro1 color new Grass

		// el layout del panel uno esta null para poder mover los componentes
		// manualmente
		panelNorte.setLayout(new BorderLayout());// panelNorte es el norte-titulo

//dimensiones de los paneles		
		panelNorte.setPreferredSize(new Dimension(100, 80));

		panelSur.setPreferredSize(new Dimension(100, 80));
		panelCentro.setPreferredSize(new Dimension(100, 100));


//agregar paneles a sus respectivas posiciones

		this.add(panelNorte, BorderLayout.NORTH);
		this.add(panelSur, BorderLayout.SOUTH);
		this.add(panelCentro, BorderLayout.CENTER);
		// panel norte-titulo agregar label y botones
		panelNorte.add(labelTitulo, BorderLayout.WEST);
	}
	private void otro(){
	
		
				ImageIcon imagen1 = new ImageIcon("imagenes/AjedrezDeCampeonato.jpg"); // Creamos «imagen1»

				JLabel etiqueta1 = new JLabel(); // Creamos «etiqueta1» y le añadimos «imagen1»

				etiqueta1.setBounds(10, 10, 200, 200);

				etiqueta1.setIcon(new ImageIcon(
						imagen1.getImage().getScaledInstance(etiqueta1.getWidth(), etiqueta1.getHeight(), Image.SCALE_SMOOTH)));
				// Ancho, alto y tipo de escalado
				
				JTextArea areaTexto= new JTextArea();
				areaTexto.setBounds(20, 20, 30, 20);
				areaTexto.setText("Juego de Campeonato Mundial de Ajedrez Completo Oficial Torneo");
				areaTexto.setEditable(false);//Desabilitar el editado del área de texto
		
				
				panelCentro.add(areaTexto);
				panelCentro.add(etiqueta1);// La añadimos al panel central

				

	}
		
		
	

}

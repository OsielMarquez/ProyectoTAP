/*

 */
package repositorio;

/**

 */
public class Repositorio {
    
}

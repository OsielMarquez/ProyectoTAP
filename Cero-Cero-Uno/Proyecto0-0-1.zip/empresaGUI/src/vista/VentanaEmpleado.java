
package vista;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt. Font; 
import java.awt.GridBagConstraints; 
import java.awt.GridBagLayout; 
import java.awt. Insets; 
import java.awt.event.KeyEvent; 
import javax.swing.JComponent; 
import javax. swing. JLabel; 
import javax. swing. JPanel; 
import javax. swing. JTextField; 
import utilerias.WrapperKey; 

/**
 *
 * @author ssk
 * 			
 */
public class VentanaEmpleado {
	public class VentanEmpleado extends JPanel{
		JLabel lbl_nombre; 
		JLabel lbl_curp; 
		JLabel lbl_peso; 
		JLabel lbl_estatura; 
		JLabel lbl_fechaNacimiento; 
		JLabel Ibl_fechaNacimientoDia; 
		JLabel lbl_fechaNacimientoMes; 
		JLabel lbl_fechaNacimientoAño; 
		JLabel lbl_puesto; 
		JLabel lbl_salario; 
		JLabel lbl_departamento; 
		JLabel Ibl_fechaIngreso; 
		JLabel lbl_fechaIngresoDia; 
		JLabel Ibl_fechaIngresoMes; 
		JLabel lbl_fechaIngresoAño; 
		JPanel panel_fechaNacimiento; 
		JPanel panel_fechaIngreso;
		JPanel panel_botones;
		//
		JTextField txt_nombre;
		JTextField txt_curp;
		JTextField txt_peso;
		JTextField txt_estatura;
		JTextField txt_fechaNacimientoDia;
		JTextField txt_fechaNacimientoMes; 
		JTextField txt_fechaNacimientoАño;
		JTextField txt_puesto;
		JTextField txt_salario;
		JTextField txt_departamento;
		JTextField txt_fechaIngresoDia; 
		JTextField txt_fechaIngresoMes; 
		JTextField txt_fechaIngresoAño;		
	
		public VentanaEmpleado(){
			this.setLayout(new GridBagLayout());
			 this.setBackground(Color.CYAN);
			 
			 Font font_labels_txt_txt = new Font("arial", Font.BOLD, 15); 
			 Color color_labels = new Color (0,0,255,100);
			 ////
				lbl_nombre = new JLabel ("NOMBRE: ");
				lbl_curp = new JLabel ("CURP: ");
				lbl_peso = new JLabel ("PESO: ");
				lbl_estatura = new JLabel ("ESTATURA: ");
				lbl_fechaNacimiento = new JLabel ("FECHA NAC:"); 
				lbl_fechaNacimientoDia = new JLabel ("DIA:"); 
				lbl_fechaNacimientoMes = new JLabel ("MES:"); 
				lbl_fechaNacimientoAño = new JLabel ("AÑO:");
				lbl_puesto = new JLabel ("PUESTO: ");
				lbl_salario = new JLabel ("SALARIO: "); 
				lbl_departamento = new JLabel ("DEPTO: "); 
				lbl_fechaIngreso = new JLabel ("FECHA ING"); 
				lbl fechaIngresoDia = new JLabel ("DIA"); 
				lbl_fechaIngresoMes = new JLabel ("MES"); 
				lbl_fechaIngresoAño = new JLabel ("AÑO");
				//
				
				lbl_nombre.setFont(font_labels_txt_txt);
				lbl_nombre.setFont (font_labels_txt_txt); 
				lbl_curp.setFont (font_labels_txt_txt); 
				lbl_peso.setFont (font_labels_txt_txt);
				lbl_estatura.setFont(font_labels_txt_txt);
				
				lbl_fechaNacimiento.setFont(font_labels_txt_txt); 
				lbl_fechaNacimientoDia.setFont(font_labels_txt_txt); 
				lbl_fechaNacimientoMes.setFont(font_labels_txt_txt);
				lbl_fechaNacimientoAño.setFont(font_labels_txt_txt); 
				lbl_puesto.setFont(font_labels_txt_txt); 
				lbl_salario.setFont(font_labels_txt_txt); 
				lbl_departamento.setFont(font_labels_txt_txt);
				lbl_fechaIngreso.setFont(font_labels_txt_txt);
				lbl_fechaIngresoDia.setFont (font_labels_txt_txt); 
				lbl_fechaIngresoMes.setFont (font_labels_txt_txt); 
				lbl_fechaIngresoAño.setFont (font_labels_txt_txt);
				
				lbl_nombre.setForeground (color_labels); 
				lbl_nombre.setForeground (color_labels); 
				lbl_curp.setForeground (color_labels);
				lbl_peso.setForeground(color_labels);
				lbl_estatura.setForeground (color_labels); 
				lbl_fechaNacimiento.setForeground (color_labels); 
				lbl_fechaNacimientoDia.setForeground (color_labels);
////
		
		}
			

			
	}
}

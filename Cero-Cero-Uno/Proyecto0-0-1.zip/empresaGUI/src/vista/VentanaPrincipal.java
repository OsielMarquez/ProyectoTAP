package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import utilerias.WrapperMouse;

public class VentanaPrincipal extends JFrame {
  
    JPanel panel_norte;
    JPanel panel_oeste;
    JPanel panel_centro;
    
    JLabel lbl_titulo;
    
    JPanel panel_oeste_principal;
    JPanel panel_oeste_empleado;
    JPanel panel_oeste_linea;
    JPanel panel_oeste_fecha;
    JPanel panel_oeste_salir;
    
    JLabel lbl_panel_oeste_principal = new JLabel("     HOME    ");
    JLabel lbl_panel_oeste_empleado = new JLabel("     HOME    ");
    JLabel lbl_panel_oeste_linea = new JLabel("     HOME    ");
   JLabel lbl_fecha_oeste_fecha = new JLabel("     FECHA     "); 
   JLabel lbl_panel_oeste_salir  = new JLabel("     FECHA     ");
   //constructor 
   public VentanaPrincipal(){
       super("DISEÑO BORDER LAYOUT");
       
  panel_norte = new JPanel();  
  panel_norte.setBackground(Color.red);  
  panel_oeste = new JPanel(); 
  panel_oeste.setBackground(Color.yellow); 
  panel_centro = new JPanel();
  panel_centro.setBackground(Color.orange); 
  panel_centro.setLayout(new BorderLayout());    
       
  Font fTitulo = new Font("Algerian", Font.BOLD,24);     
  lbl_titulo = new JLabel("ADMINISTRADORES DE DISEÑO");     
  lbl_titulo.setFont(fTitulo);
       
  panel_norte.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
  panel_norte.add(lbl_titulo);
  
  BoxLayout caja = new BoxLayout(panel_oeste, BoxLayout.Y_AXIS);
  panel_oeste.setLayout(caja);
  panel_oeste.setCursor(new Cursor(Cursor.HAND_CURSOR));
  
 panel_oeste_principal = new JPanel(); 
 panel_oeste_principal.setBackground(Color.YELLOW);
 panel_oeste_principal.setLayout(new BorderLayout(5, 5));
 panel_oeste_principal.add(lbl_panel_oeste_principal,
               BorderLayout.CENTER); 
 
panel_oeste_empleado = new JPanel();
panel_oeste_empleado.setLayout(new BorderLayout());
panel_oeste_empleado.setBackground(Color.YELLOW);
panel_oeste_empleado.add(lbl_panel_oeste_empleado, BorderLayout.CENTER);

panel_oeste_linea = new JPanel();
panel_oeste_linea.setLayout(new BorderLayout());
panel_oeste_linea.setBackground(Color.YELLOW);
panel_oeste_linea.add(lbl_panel_oeste_linea, BorderLayout.CENTER);

panel_oeste_fecha = new JPanel();
panel_oeste_fecha.setLayout(new BorderLayout());
panel_oeste_fecha.setBackground(Color.YELLOW);
panel_oeste_fecha.add(lbl_fecha_oeste_fecha, BorderLayout.CENTER);

panel_oeste_salir = new JPanel();
panel_oeste_salir.setLayout(new BorderLayout());
panel_oeste_salir.setBackground(Color.YELLOW);
panel_oeste_salir.add(lbl_panel_oeste_salir, BorderLayout.CENTER);

//acciones del mouse en el principal


panel_oeste_principal.addMouseListener(new WrapperMouse(){
 @Override
 public void mouseClicked(MouseEvent e) {
   Principal ppal = new Principal();  
   mostrarPanels(ppal);  
 }
 
 @Override 
 public void mouseEntered(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_principal, Color.BLUE,
   lbl_panel_oeste_principal, Color.YELLOW);
 }
 
 @Override
 public void mouseExited(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_principal, Color.YELLOW,
   lbl_panel_oeste_principal, Color.BLUE);
 }
 
 });
//acciones del mouse en oeste para empleados
panel_oeste_empleado.addMouseListener(new WrapperMouse(){
@Override     
 public void mouseClicked(MouseEvent e) {
   VentanaEmpleado uno = new VentanaEmpleado();  
   mostrarPanels(uno);  
 }
 
 @Override 
 public void mouseEntered(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_empleado, Color.BLUE,
   lbl_panel_oeste_empleado, Color.YELLOW);
 }
 
 @Override
 public void mouseExited(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_principal, Color.YELLOW,
   lbl_panel_oeste_empleado, Color.BLUE);
 }
 
 });
//acciones del mouse para oeste linea
panel_oeste_linea.addMouseListener(new WrapperMouse(){
@Override     
 public void mouseClicked(MouseEvent e) {
  // AppLinea uno = new VentanaEmpleado();  
   //mostrarPanels(uno);  
 }
 
 @Override 
 public void mouseEntered(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_linea, Color.BLUE,
   lbl_panel_oeste_linea, Color.YELLOW);
 }
 
 @Override
 public void mouseExited(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_linea, Color.YELLOW,
   lbl_panel_oeste_linea, Color.BLUE);
 }
 
 });
//acciones del mouse para fecha oeste
fecha_oeste_fecha.addMouseListener(new WrapperMouse(){
@Override 
 public void mouseClicked(MouseEvent e) {
   //AppFecha uno = new AppFecha();  
   //mostrarPanels(uno);  
 }
 
 @Override 
 public void mouseEntered(MouseEvent e) {
   coloresOpcionesMenu(fecha_oeste_fecha, Color.BLUE,
   lbl_fecha_oeste_fecha, Color.YELLOW);
 }
 
 @Override
 public void mouseExited(MouseEvent e) {
   coloresOpcionesMenu(fecha_oeste_fecha, Color.YELLOW,
   lbl_fecha_oeste_fecha, Color.BLUE);
 }
 
 });

//acciones del mouse para panel oeste salir
panel_oeste_salir.addMouseListener(new WrapperMouse(){
@Override    
 public void mouseClicked(MouseEvent e) {
   System.exit(0);
 }
 
 @Override 
 public void mouseEntered(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_salir, Color.BLUE,
   lbl_panel_oeste_salir, Color.YELLOW);
 }
 
 @Override
 public void mouseExited(MouseEvent e) {
   coloresOpcionesMenu(panel_oeste_salir, Color.YELLOW,
   lbl_panel_oeste_salir, Color.BLUE);
 }
 
 });

panel_oeste.add(panel_oeste_principal);
panel_oeste.add(panel_oeste_empleado);
panel_oeste.add(panel_oeste_linea);
panel_oeste.add(fecha_oeste_fecha);
panel_oeste.add(panel_oeste_salir);


///

//Inicialmente cargar el panel principal

	panel_centro.add(new Principal(), BorderLayout.CENTER);

//No se necesita por que  es por default de los JFrames
//this.setLayout(new BorderLayout();

	this.add(panel_norte, BorderLayout.NORTH);
	this.add(panel_oeste, BorderLayout.WEST);
	this.add(panel_centro, BorderLayout.CENTER);

//this.setSize(800,600);

	this.pack();

//this.setMaximumSize(new Dimesion(600,300));
//this.setMaximumSize(new Dimension(1000,600));

	this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	this.setLocationRelativeTo(null);
	//this.setResizable(false);
   } 
   public static void main(String[] args) {
	   new VentanaPrincipal().setVisible(true);
   }
    private void coloresOpcionesMenu(JPanel panel, Color back, JLabel etiqueta, Color fore) {
    	panel.setBackground(back);
    	etiqueta.setBackground(fore);
    }
    
    private void mostrarPanels(JPanel ventana) {
    	panel_centro.removeAll();
    	panel_centro.add(ventana, BorderLayout.CENTER);
    	panel_centro.revalidate();
    	panel_centro.repaint();
    	this.pack();
    }

}

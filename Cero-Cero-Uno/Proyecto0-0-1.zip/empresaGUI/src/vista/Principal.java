
package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author ssk
 */

public class Principal extends JPanel {

	JPanel panel_imagen;
	JLabel lbl_imagen;

	public Principal() {
		panel_imagen = new JPanel();
		panel_imagen.setBackground(Color.LIGHT_GRAY);
		lbl_imagen = new JLabel();
		String pathimagen = "/iconos/banco.png";
		ImageIcon imagen = new ImageIcon(getClass().getResource(pathimagen));
		lbl_imagen.setIcon(imagen);
		panel_imagen.add(lbl_imagen, BorderLayout.CENTER);
		panel_imagen.repaint();

		this.setLayout(new BorderLayout());
		// this.add(lbl_imagen, BorderLayout.CENTER);
		this.add(panel_imagen, BorderLayout.CENTER);

	}

}

/*

 */
package controlador;

import vista.VentanaPrincipal;

/**

 */
public class Empresa {
    //metodo main
    public static void main(String[] args) {
      new VentanaPrincipal().setVisible(true);  
    }
    
}
